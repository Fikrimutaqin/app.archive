<?php

class Login extends Controller
{

    public function __construct()
    {
    }
    public function index()
    {
        if (isset($_SESSION['email']) == 1) {
            header('Location: ' . BASEURL . '/dashboard');
        }
        $data = [
            'title' => 'Form Login'
        ];
        $this->view('templates/__newTemplate/header', $data);
        $this->view('login/form-login/index');
        $this->view('templates/__newTemplate/footer');
    }

    public function postLogin()
    {
        $this->model('Login_model')->checkLogin();
    }

    public function _logout()
    {
        session_start();
        session_destroy();

        header('Location: ' . BASEURL . '/');
    }

    public function forgot()
    {

        $email = $_POST['email'];
        $data = $this->model('Login_model')->checkForgotPassword($email);

        if ($data) {
            $data1 = [
                'title' => 'Forgot Password',
                'view' => $this->model('Login_model')->getDataSingelType($email),
            ];
            $this->view('templates/__newTemplate/header', $data1);
            $this->view('login/form-login/forgot', $data1);
            $this->view('templates/__newTemplate/footer');
        } else {
            header('Location:' . BASEURL . '/');
            Flasher::setFlash('Error', 'Email tidak terdaftar', 'bg-danger');
            exit;
        }
    }

    public function changePassword()
    {
        $data = [
            'users_id' => $_POST['users_id'],
            'password' => md5($_POST['newpass']),
        ];

        $sql = $this->model('Login_model')->updatPassword($data);
        if ($sql) {
            header('Location:' . BASEURL . '/');
            Flasher::setFlash('Success', 'Update Password SuccessFully', 'bg-success');
            exit;
        } else {
            header('Location:' . BASEURL . '/');
            Flasher::setFlash('Error', 'Failed Update Password', 'bg-danger');
            exit;
        }
    }
}
