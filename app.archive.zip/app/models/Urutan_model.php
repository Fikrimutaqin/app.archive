<?php
class Urutan_model
{
    private $tabel = 'urutan';
    private $db;


    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllUrutan()
    {
        try {
            $this->db->query("SELECT * FROM $this->tabel");
            return $this->db->resultSet();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }


    //add data ruang to db
    public function addDataUrutan($data)
    {
        try {
            $query =
                "INSERT INTO $this->tabel 
                        VALUES 
                        ('', :cd_storage, :cd_urutan, :data, :status, :date_created, :author )";

            $this->db->query($query);
            $this->db->bind('cd_storage', $data['cd_storage']);
            $this->db->bind('cd_urutan', $data['cd_urutan']);
            $this->db->bind('data', $data['data']);
            $this->db->bind('status', $data['status']);
            $this->db->bind('date_created', $data['date_created']);
            $this->db->bind('author', $data['author']);

            $this->db->execute();

            return $this->db->rowCount();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function checkCdUrutan()
    {
        try {
            $this->db->query("SELECT MAX(cd_urutan) as kode from $this->tabel");
            $result =  $this->db->single();
            return $result['kode'];
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function countRowUrutan()
    {
        try {
            $this->db->query("SELECT COUNT(*) as num from $this->tabel");
            $result =  $this->db->resultSet();
            return $result;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function getDataSingel($code_storage)
    {
        try {
            $query = "SELECT count(*) as num FROM $this->tabel WHERE cd_storage= :cd_storage";
            $this->db->query($query);
            $this->db->bind('cd_storage', $code_storage);

            return $this->db->single();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}
